# Validador automatizado — EFD ICMS/IPI

Pacote para receber um arquivo SPED por webhook do n8n, executar validações padronizadas, salvar o histórico no Supabase e devolver um relatório JSON com comparação contra a execução anterior do mesmo CNPJ e competência.

## Arquivos

- `workflow-n8n.json`: importe diretamente no n8n.
- `supabase.sql`: execute uma vez no SQL Editor do Supabase.
- `validator.js` e `compare.js`: cópias editáveis dos códigos usados nos nós do workflow.

## Configuração

1. Execute `supabase.sql` no projeto Supabase.
2. No servidor do n8n, defina `SUPABASE_URL` e `SUPABASE_SERVICE_ROLE_KEY` como variáveis de ambiente e reinicie o n8n.
3. Importe `workflow-n8n.json`, abra os dois nós HTTP do Supabase e confirme que expressões com `$env` são permitidas na sua instalação.
4. Ative o workflow e copie a URL de produção do webhook.

## Envio

Envie `POST multipart/form-data` para o webhook, usando o campo de arquivo `data`:

```bash
curl -X POST "https://SEU-N8N/webhook/validar-efd-icms-ipi" \
  -F "data=@arquivo-sped.txt"
```

O retorno inclui `status`, contagens por gravidade, lista de inconsistências, totais apurados e `comparison`. Na primeira execução de cada CNPJ/competência, `comparison.first_execution` será `true`.

## Validações incluídas

- delimitadores e códigos de registro;
- abertura, encerramento e unicidade dos registros estruturais;
- quantidades dos encerramentos de blocos, registro 9999 e registros 9900;
- CNPJ e período do registro 0000;
- chave de acesso e possível duplicidade de documentos C100;
- hierarquia básica C100/C170/C190;
- direção da operação versus série do CFOP em C170;
- comparação entre VL_DOC do C100 e VL_OPR dos C190;
- conciliação do inventário H005/H010;
- totais comparáveis de documentos, ICMS, ICMS-ST, IPI e inventário.

## Segurança e evolução

A chave `service_role` deve permanecer somente no n8n. Esta versão faz validações preventivas determinísticas; ela não substitui a validação no PVA. Regras específicas do Paraná, tabela 5.1.1, benefícios, CIAP e cruzamentos com XML podem ser acrescentadas em uma segunda camada sem alterar o webhook.
