const input = $input.first();
const binaryKey = Object.keys(input.binary || {})[0];
if (!binaryKey) throw new Error('Envie o SPED como arquivo binário no campo data (multipart/form-data).');

const buffer = await this.helpers.getBinaryDataBuffer(0, binaryKey);
let text = buffer.toString('latin1').replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
const rawLines = text.split('\n');
while (rawLines.length && !rawLines[rawLines.length - 1].trim()) rawLines.pop();
const lines = rawLines.map((raw, i) => ({ no: i + 1, raw, f: raw.split('|'), reg: raw.split('|')[1] || '' }));

const issues = [];
const add = (severity, code, message, line = null, details = null) => issues.push({ severity, code, message, line, details });
const num = v => Number(String(v || '').replace(/\./g, '').replace(',', '.')) || 0;
const onlyDigits = v => String(v || '').replace(/\D/g, '');
const dateBR = v => { const s = onlyDigits(v); return s.length === 8 ? `${s.slice(4,8)}-${s.slice(2,4)}-${s.slice(0,2)}` : null; };
const round2 = v => Math.round((v + Number.EPSILON) * 100) / 100;

if (!lines.length) throw new Error('O arquivo enviado está vazio.');
for (const l of lines) {
  if (!l.raw.startsWith('|') || !l.raw.endsWith('|')) add('erro', 'ESTRUTURA_LINHA', 'A linha deve iniciar e terminar com |.', l.no);
  if (!l.reg) add('erro', 'REGISTRO_AUSENTE', 'Código do registro não identificado.', l.no);
}

const byReg = {};
for (const l of lines) (byReg[l.reg] ||= []).push(l);
const count = reg => (byReg[reg] || []).length;
const unique = ['0000','0001','0990','9001','9990','9999'];
for (const reg of unique) {
  if (!count(reg)) add('erro', 'REGISTRO_OBRIGATORIO', `Registro ${reg} não encontrado.`);
  if (count(reg) > 1) add('erro', 'REGISTRO_DUPLICADO', `Registro ${reg} aparece ${count(reg)} vezes.`);
}
if (lines[0]?.reg !== '0000') add('erro', 'PRIMEIRO_REGISTRO', 'O primeiro registro deve ser 0000.', lines[0]?.no);
if (lines.at(-1)?.reg !== '9999') add('erro', 'ULTIMO_REGISTRO', 'O último registro deve ser 9999.', lines.at(-1)?.no);

const r0000 = byReg['0000']?.[0];
const metadata = r0000 ? {
  cod_ver: r0000.f[2], cod_fin: r0000.f[3], dt_ini: dateBR(r0000.f[4]), dt_fin: dateBR(r0000.f[5]),
  nome: r0000.f[6], cnpj: onlyDigits(r0000.f[7]), cpf: onlyDigits(r0000.f[8]), uf: r0000.f[9], ie: r0000.f[10],
  perfil: r0000.f[14], atividade: r0000.f[15]
} : {};
if (metadata.cnpj && metadata.cnpj.length !== 14) add('erro', 'CNPJ_INVALIDO', 'CNPJ do registro 0000 deve ter 14 dígitos.', r0000?.no);
if (!metadata.dt_ini || !metadata.dt_fin) add('erro', 'PERIODO_INVALIDO', 'Datas inicial/final inválidas no registro 0000.', r0000?.no);
if (metadata.dt_ini && metadata.dt_fin && metadata.dt_ini > metadata.dt_fin) add('erro', 'PERIODO_INVERTIDO', 'Data inicial posterior à data final.', r0000?.no);

const closingChecks = [
  ['0990','0'], ['C990','C'], ['D990','D'], ['E990','E'], ['G990','G'], ['H990','H'], ['K990','K'], ['1990','1'], ['9990','9']
];
for (const [closing, block] of closingChecks) {
  const row = byReg[closing]?.[0];
  if (!row) continue;
  const informed = Number(row.f[2]);
  const actual = lines.filter(x => x.reg.startsWith(block)).length;
  if (informed !== actual) add('erro', 'TOTAL_BLOCO', `${closing}: quantidade informada ${informed}, calculada ${actual}.`, row.no, { informado: informed, calculado: actual });
}
const r9999 = byReg['9999']?.[0];
if (r9999 && Number(r9999.f[2]) !== lines.length) add('erro', 'TOTAL_ARQUIVO', `9999 informa ${r9999.f[2]} linhas, mas o arquivo possui ${lines.length}.`, r9999.no);

for (const row of byReg['9900'] || []) {
  const target = row.f[2];
  const informed = Number(row.f[3]);
  const actual = count(target);
  if (informed !== actual) add('erro', 'TOTAL_REGISTRO_9900', `9900/${target}: informado ${informed}, calculado ${actual}.`, row.no);
}

function validAccessKey(key) {
  const s = onlyDigits(key);
  if (s.length !== 44 || /^(\d)\1+$/.test(s)) return false;
  const body = s.slice(0, 43).split('').reverse().map(Number);
  let weight = 2, sum = 0;
  for (const d of body) { sum += d * weight; weight = weight === 9 ? 2 : weight + 1; }
  const mod = sum % 11; const dv = mod === 0 || mod === 1 ? 0 : 11 - mod;
  return dv === Number(s[43]);
}

const seenDocs = new Map();
let currentC100 = null;
const c190ByDoc = new Map();
for (const l of lines) {
  if (l.reg === 'C100') {
    currentC100 = l;
    const key = onlyDigits(l.f[9]);
    const docId = key || `${l.f[6]}|${l.f[7]}|${l.f[8]}`;
    if (seenDocs.has(docId)) add('alerta', 'DOCUMENTO_DUPLICADO', `Possível documento duplicado; primeira ocorrência na linha ${seenDocs.get(docId)}.`, l.no, { documento: docId });
    else seenDocs.set(docId, l.no);
    if (key && !validAccessKey(key)) add('erro', 'CHAVE_ACESSO_INVALIDA', 'Chave de acesso do C100 inválida (44 dígitos/DV).', l.no, { chave: key });
    c190ByDoc.set(l.no, 0);
  } else if (l.reg === 'C190') {
    if (!currentC100) add('erro', 'HIERARQUIA_C190', 'C190 encontrado sem C100 anterior no documento.', l.no);
    else c190ByDoc.set(currentC100.no, round2((c190ByDoc.get(currentC100.no) || 0) + num(l.f[5])));
  } else if (l.reg === 'C170') {
    if (!currentC100) add('erro', 'HIERARQUIA_C170', 'C170 encontrado sem C100 anterior no documento.', l.no);
    const cfop = onlyDigits(l.f[11]);
    if (currentC100 && cfop.length === 4) {
      const indOper = currentC100.f[2];
      const first = cfop[0];
      if (indOper === '0' && !'123'.includes(first)) add('alerta', 'CFOP_OPERACAO', `Entrada com CFOP ${cfop} fora das séries 1/2/3.`, l.no);
      if (indOper === '1' && !'567'.includes(first)) add('alerta', 'CFOP_OPERACAO', `Saída com CFOP ${cfop} fora das séries 5/6/7.`, l.no);
    }
  } else if (/^[CD]100$/.test(l.reg) === false && /^[CD]990$/.test(l.reg)) {
    currentC100 = null;
  }
}
for (const [lineNo, totalC190] of c190ByDoc.entries()) {
  const doc = lines[lineNo - 1];
  const vlDoc = round2(num(doc.f[12]));
  if (totalC190 && Math.abs(totalC190 - vlDoc) > 0.02) add('alerta', 'TOTAL_C100_C190', `C100 VL_DOC ${vlDoc.toFixed(2)} difere da soma VL_OPR dos C190 ${totalC190.toFixed(2)}.`, lineNo);
}

for (const h005 of byReg['H005'] || []) {
  const nextH005 = (byReg['H005'] || []).find(x => x.no > h005.no)?.no || (byReg['H990']?.[0]?.no || lines.length + 1);
  const total = lines.filter(x => x.no > h005.no && x.no < nextH005 && x.reg === 'H010').reduce((s, x) => s + num(x.f[4]), 0);
  const informed = num(h005.f[3]);
  if (Math.abs(total - informed) > 0.02) add('alerta', 'TOTAL_INVENTARIO', `H005 VL_INV ${informed.toFixed(2)} difere da soma dos H010 ${total.toFixed(2)}.`, h005.no);
}

const counts = Object.fromEntries(Object.entries(byReg).map(([k,v]) => [k, v.length]).sort());
const values = {
  vl_doc_c100: round2((byReg['C100'] || []).reduce((s,x) => s + num(x.f[12]), 0)),
  vl_opr_c190: round2((byReg['C190'] || []).reduce((s,x) => s + num(x.f[5]), 0)),
  vl_icms_c190: round2((byReg['C190'] || []).reduce((s,x) => s + num(x.f[7]), 0)),
  vl_icms_st_c190: round2((byReg['C190'] || []).reduce((s,x) => s + num(x.f[9]), 0)),
  vl_ipi_c190: round2((byReg['C190'] || []).reduce((s,x) => s + num(x.f[11]), 0)),
  vl_inv_h005: round2((byReg['H005'] || []).reduce((s,x) => s + num(x.f[3]), 0))
};
let hash = 2166136261;
for (let i = 0; i < text.length; i++) { hash ^= text.charCodeAt(i); hash = Math.imul(hash, 16777619); }
const severity = issues.reduce((a,x) => ((a[x.severity] = (a[x.severity] || 0) + 1), a), { erro: 0, alerta: 0, info: 0 });
const competence = metadata.dt_fin ? metadata.dt_fin.slice(0,7) : null;

return [{ json: {
  execution_id: (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`,
  executed_at: new Date().toISOString(), file_name: input.binary[binaryKey].fileName || 'sped.txt', file_hash: (hash >>> 0).toString(16).padStart(8,'0'),
  cnpj: metadata.cnpj || null, competence, metadata, line_count: lines.length, register_counts: counts,
  totals: values, issue_counts: severity, issues, status: severity.erro ? 'com_erros' : severity.alerta ? 'com_alertas' : 'ok'
} }];
