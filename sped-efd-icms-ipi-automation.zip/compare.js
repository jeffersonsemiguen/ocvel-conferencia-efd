const current = $('Validar EFD ICMS IPI').first().json;
const response = $input.first().json;
const previous = Array.isArray(response) ? response[0] : (response?.body?.[0] || null);
const deltaObject = (now = {}, before = {}) => Object.fromEntries(
  [...new Set([...Object.keys(now), ...Object.keys(before)])].sort().map(k => [k, round((now[k] || 0) - (before[k] || 0))])
);
const round = v => Math.round((Number(v) + Number.EPSILON) * 100) / 100;
const comparison = previous ? {
  previous_execution_id: previous.execution_id,
  previous_executed_at: previous.executed_at,
  previous_file_name: previous.file_name,
  status_changed: previous.status !== current.status,
  previous_status: previous.status,
  issue_delta: deltaObject(current.issue_counts, previous.issue_counts),
  total_delta: deltaObject(current.totals, previous.totals),
  register_delta: deltaObject(current.register_counts, previous.register_counts),
  new_issue_codes: [...new Set(current.issues.map(x => x.code))].filter(x => !(previous.issue_codes || []).includes(x)),
  resolved_issue_codes: (previous.issue_codes || []).filter(x => !current.issues.some(y => y.code === x))
} : { first_execution: true };
return [{ json: { ...current, comparison, issue_codes: [...new Set(current.issues.map(x => x.code))] } }];
