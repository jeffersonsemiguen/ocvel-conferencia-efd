create extension if not exists pgcrypto;

create table if not exists public.sped_efd_runs (
  id uuid primary key default gen_random_uuid(),
  execution_id text not null unique,
  executed_at timestamptz not null default now(),
  cnpj text,
  competence text,
  file_name text not null,
  file_hash text not null,
  status text not null check (status in ('ok','com_alertas','com_erros')),
  line_count integer not null,
  metadata jsonb not null default '{}'::jsonb,
  register_counts jsonb not null default '{}'::jsonb,
  totals jsonb not null default '{}'::jsonb,
  issue_counts jsonb not null default '{}'::jsonb,
  issue_codes jsonb not null default '[]'::jsonb,
  issues jsonb not null default '[]'::jsonb,
  comparison jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists sped_efd_runs_company_period_idx
  on public.sped_efd_runs (cnpj, competence, executed_at desc);
create index if not exists sped_efd_runs_hash_idx on public.sped_efd_runs (file_hash);

alter table public.sped_efd_runs enable row level security;

-- O workflow usa a service_role apenas no servidor do n8n. Não exponha essa chave no navegador.
